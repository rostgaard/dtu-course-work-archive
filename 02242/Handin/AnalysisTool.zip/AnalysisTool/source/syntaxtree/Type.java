package syntaxtree;

/**
 * Data representation for supported types
 *
 */
public enum Type {

	INT, ARRAY;	
	
}
