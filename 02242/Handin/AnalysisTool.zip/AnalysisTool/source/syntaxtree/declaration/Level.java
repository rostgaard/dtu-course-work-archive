package syntaxtree.declaration;

/**
 *  Data representation for high/low security level
 *
 */
public enum Level {
	
	HIGH, LOW, UNKNOWN;
	
}
