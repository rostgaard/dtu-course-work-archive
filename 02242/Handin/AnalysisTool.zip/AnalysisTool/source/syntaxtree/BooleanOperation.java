package syntaxtree;

/**
 * Data representation for supported boolean operations
 *
 */
public enum BooleanOperation {

    AND, OR;
}
