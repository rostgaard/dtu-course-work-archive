package analysis;

import flowgraph.datastructure.Flow;
import java.util.LinkedList;

/**
 *
 * @author krc
 */
public class Worklist extends LinkedList<Flow>{}
