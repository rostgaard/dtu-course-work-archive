/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package analysis;

/**
 *
 * @author krc
 */
public enum Intervals {
    IN_RANGE,
    MINUS_INF,
    INF,
    MIN,
    MAX
}
