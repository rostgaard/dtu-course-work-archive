package analysis;

/**
 * Created with IntelliJ IDEA.
 * User: peter
 * Date: 30/11/13
 * Time: 10.57
 * To change this template use File | Settings | File Templates.
 */
public enum Bool {
    FF,
    TT
}
