/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package analysis;

/**
 *
 * @author krc
 */
public abstract class ProgramState {

    public void addEntry(int label, DefinitionSet definitionSet) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
