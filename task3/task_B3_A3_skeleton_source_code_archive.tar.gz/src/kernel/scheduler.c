/*! \file scheduler.c
   Implement the non-preemptive scheduler here. 
 */
